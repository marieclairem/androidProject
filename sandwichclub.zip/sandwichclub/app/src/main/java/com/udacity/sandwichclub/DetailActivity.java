package com.udacity.sandwichclub;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;
import com.udacity.sandwichclub.model.Sandwich;
import com.udacity.sandwichclub.utils.JsonUtils;
import java.util.List;

public class DetailActivity extends AppCompatActivity {

    public static final String EXTRA_POSITION = "extra_position";
    private static final int DEFAULT_POSITION = -1;
   // private Sandwich sandwichObj;
    private ImageView sandwich_Image_tv;
    private TextView sandwich_origin_tv_label;
    private TextView sandwich_origin_tv;
    private TextView sandwich_also_know_tv_label;
    private TextView sandwich_also_know_tv;
    private TextView sandwich_ingredients_tv;
    private TextView sandwich_description_tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        sandwich_Image_tv = findViewById(R.id.image_iv);
        sandwich_origin_tv_label = findViewById(R.id.origin_label);
        sandwich_origin_tv = findViewById(R.id.origin_tv);
        sandwich_also_know_tv_label = findViewById(R.id.also_known_label);
        sandwich_also_know_tv = findViewById(R.id.also_known_tv);
        sandwich_ingredients_tv = findViewById(R.id.ingredients_tv);
        sandwich_description_tv = findViewById(R.id.description_tv);

        Intent intent = getIntent();
        if (intent == null) {
            closeOnError();
        }

        int position = intent.getIntExtra(EXTRA_POSITION, DEFAULT_POSITION);
        if (position == DEFAULT_POSITION) {

            closeOnError();
            return;
        }

        String[] sandwiches = getResources().getStringArray(R.array.sandwich_details);
        String json = sandwiches[position];
        Sandwich sandwich = JsonUtils.parseSandwichJson(json);

        if (sandwich == null) {

            closeOnError();
            return;
        }

        setTitle(sandwich.getMainName());
        populateUI(sandwich);
    }

    private void closeOnError() {
        finish();
        Toast.makeText(this, R.string.detail_error_message, Toast.LENGTH_SHORT).show();
    }

    private void populateUI(Sandwich sandwich) {
        Picasso.with(this)
                .load(sandwich.getImage())
                .into(sandwich_Image_tv);

        if (sandwich.getPlaceOfOrigin().isEmpty()) {

            sandwich_origin_tv_label.setVisibility(View.GONE);
            sandwich_origin_tv.setVisibility(View.GONE);
        } else {
            sandwich_origin_tv.setText(sandwich.getPlaceOfOrigin());
        }

        if (sandwich.getAlsoKnownAs().isEmpty()) {

            sandwich_also_know_tv_label.setVisibility(View.GONE);
            sandwich_also_know_tv.setVisibility(View.GONE);
        } else {
            List<String> list = sandwich.getAlsoKnownAs();
            String list_str = TextUtils.join(", ", list);
            sandwich_also_know_tv.setText(list_str);
        }

        sandwich_description_tv.setText(sandwich.getDescription());

        List<String> ingreList = sandwich.getIngredients();
        String ingreList_str = TextUtils.join(", ", ingreList);
        sandwich_ingredients_tv.setText(ingreList_str);
    }
}